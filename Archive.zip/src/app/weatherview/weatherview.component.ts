import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weatherview',
  templateUrl: './weatherview.component.html',
  styleUrls: ['./weatherview.component.scss']
})
export class WeatherviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
